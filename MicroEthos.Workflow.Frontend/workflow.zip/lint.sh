#!/usr/bin/env bash
cd "$(dirname "$0")"

./node_modules/.bin/eslint src
