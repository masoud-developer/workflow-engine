# Workflow Web User Interface

## Build and start

```
npm install -s
npm start
```
