import React from 'react';
import './style.css';

export function separator() {
  return (<div className="separator">&nbsp;</div>);
}
