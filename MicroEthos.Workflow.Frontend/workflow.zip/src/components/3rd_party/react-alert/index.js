// load styles
import './dev/assets/styles/alert.css';
// load js
import AlertContainer from './dev/components/AlertContainer';

export default AlertContainer;
