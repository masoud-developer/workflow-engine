export default {
  NODE_ITEM: 'node_item',
};
